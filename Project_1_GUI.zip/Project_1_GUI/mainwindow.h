/*
  Samara Holmes
  Spring 2025
  CS 5330 Computer Vision

  Main window function prototypes for GUI
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "opencv2/core.hpp"
#include <QDebug>
#include <QTimer>
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void updateFrame();                // Function to update the video frame
    void applyGreyscaleFilter();       // Slot to apply grayscale filter
    void applySepiaFilter();
    void applyBlurFilter();
    void applySobelXFilter();
    void applySobelYFilter();
    void applyMagnitudeFilter();
    void applyFaceDetect();
    void removeFilter();
    void record();
    void stopRecord();
    void quit();

private:
    Ui::MainWindow *ui;
    cv::VideoCapture *capdev;
    QTimer *videoTimer;                // Timer for video updates
    // Enum for current filter state
    enum Filter { None, Greyscale, Sepia, Blur, SobelX, SobelY, Magnitude, FaceDetect, Record, StopRecord} currentFilter;
};
#endif // MAINWINDOW_H
