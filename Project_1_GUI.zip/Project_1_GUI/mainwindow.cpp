/*
  Samara Holmes
  Spring 2025
  CS 5330 Computer Vision

  Main Window for GUI
*/

#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "filters.h"
#include "faceDetect.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , capdev(new cv::VideoCapture(0))
    , currentFilter(None)
{
    ui->setupUi(this);

    if (!capdev->isOpened()) {
        qDebug() << "Unable to open video device";
        return;
    }

    // Setup video properties
    cv::Size refS((int)capdev->get(cv::CAP_PROP_FRAME_WIDTH),
                  (int)capdev->get(cv::CAP_PROP_FRAME_HEIGHT));
    qDebug() << "Expected size:" << refS.width << refS.height;

    // Setup UI connections
    connect(ui->btnGreyscale, &QPushButton::clicked, this, &MainWindow::applyGreyscaleFilter);
    connect(ui->btnSepia, &QPushButton::clicked, this, &MainWindow::applySepiaFilter);
    connect(ui->btnBlur, &QPushButton::clicked, this, &MainWindow::applyBlurFilter);
    connect(ui->btnSobelX, &QPushButton::clicked, this, &MainWindow::applySobelXFilter);
    connect(ui->btnSobelY, &QPushButton::clicked, this, &MainWindow::applySobelYFilter);
    connect(ui->btnMagnitude, &QPushButton::clicked, this, &MainWindow::applyMagnitudeFilter);
    connect(ui->btnFaceDetect, &QPushButton::clicked, this, &MainWindow::applyFaceDetect);
    connect(ui->btnRecord, &QPushButton::clicked, this, &MainWindow::record);
    connect(ui->btnStop, &QPushButton::clicked, this, &MainWindow::stopRecord);
    connect(ui->btnNoFilter, &QPushButton::clicked, this, &MainWindow::removeFilter);
    connect(ui->btnQuit, &QPushButton::clicked, this, &MainWindow::quit);

    // Start video capture
    videoTimer = new QTimer(this);
    connect(videoTimer, &QTimer::timeout, this, &MainWindow::updateFrame);
    videoTimer->start(30); // Set timer to capture at ~30fps

}

MainWindow::~MainWindow()
{
    delete ui;
    delete capdev;
}


void MainWindow::updateFrame()
{
    cv::Mat frame;
    *capdev >> frame;
    if (frame.empty()) {
        qDebug() << "Frame is empty";
        return;
    }

    cv::Mat new_frame = frame.clone();

    // Apply the current filter
    switch (currentFilter) {
    case Greyscale:
        greyscale(frame, new_frame);
        break;
    case Sepia:
        sepia(frame, new_frame);
        break;
    case Blur:
        blur5x5_1(frame, new_frame);
        break;
    case SobelX:
        sobelX3x3(frame, new_frame);
        break;
    case SobelY:
        sobelY3x3(frame, new_frame);
        break;
    case Magnitude:
    {
        // Store Sobel results
        cv::Mat sobelX;
        cv::Mat sobelY;

        // Apply Sobel filters to new_frame and store results in sobelX and sobelY
        sobelX3x3(new_frame, sobelX);
        sobelY3x3(new_frame, sobelY);

        // Convert sobelX and sobelY to CV_16SC3 !!
        sobelX.convertTo(sobelX, CV_16SC3);
        sobelY.convertTo(sobelY, CV_16SC3);
        magnitude(sobelX, sobelY, new_frame);
    }
        break;
    default:
        new_frame = frame; // No filter applied
        break;
    }

    // Display the frame in the QLabel
    //QImage qimg(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_BGR888);
    QImage qimg(new_frame.data, new_frame.cols, new_frame.rows, new_frame.step, QImage::Format_BGR888);
    ui->videoLabel->setPixmap(QPixmap::fromImage(qimg));
    ui->videoLabel->update();
}

void MainWindow::applyGreyscaleFilter() {
    std::cout << "Greyscale button clicked" << std::endl;
    currentFilter = Greyscale;
}

void MainWindow::applySepiaFilter() {
    std::cout << "Sepia button clicked" << std::endl;
    currentFilter = Sepia;
}

void MainWindow::applyBlurFilter() {
    std::cout << "Blur button clicked" << std::endl;
    currentFilter = Blur;
}

void MainWindow::applySobelXFilter() {
    std::cout << "SobelX button clicked" << std::endl;
    currentFilter = SobelX;
}

void MainWindow::applySobelYFilter() {
    std::cout << "SobelY button clicked" << std::endl;
    currentFilter = SobelY;
}

void MainWindow::applyMagnitudeFilter() {
    std::cout << "Magnitude button clicked" << std::endl;
    currentFilter = Magnitude;
}

void MainWindow::applyFaceDetect() {
    std::cout << "FaceDetect button clicked" << std::endl;
    currentFilter = FaceDetect;
}

void MainWindow::record() {
    std::cout << "Record button clicked" << std::endl;
    currentFilter = Record;
}

void MainWindow::stopRecord() {
    std::cout << "StopRecord button clicked" << std::endl;
    currentFilter = StopRecord;
}

void MainWindow::removeFilter() {
    std::cout << "Remove Filter button clicked" << std::endl;
    currentFilter = None;
}

void MainWindow::quit() {
    QCoreApplication::quit();
}
